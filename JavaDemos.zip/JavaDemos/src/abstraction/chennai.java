package abstraction;

public class chennai extends passportHO{

	@Override
	public void idverify() {
          System.out.println("voters id for verification");		
	}

}
