package abstraction;

public abstract class Mytest {
 
	public  abstract int calculate(int a ,int b);
	
	
}
