package abstraction;

public class Main {
public static void main(String[] args) {
	add a=new add();
	a.calculate(2, 5);
}
}
