package abstraction;

public abstract class passportHO {

	public abstract void idverify();
	public abstract void display();
	
	public void sample() {
		
	}
	
}
