package abstraction;

public class Bangalore extends passportHO{

	@Override
	public void idverify() {
		 System.out.println("DL for verification");
	}

}
