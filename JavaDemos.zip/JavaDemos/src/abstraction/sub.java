package abstraction;

public class sub extends Mytest{

	@Override
	public int calculate(int a, int b) {
		int c=a-b;
		System.out.println(c);
		return c;
	}

}
