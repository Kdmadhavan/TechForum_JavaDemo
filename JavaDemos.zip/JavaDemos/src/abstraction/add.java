package abstraction;

public class add extends Mytest{

	@Override
	public int calculate(int a, int b) {
		int c=a+b;
		System.out.println(c);
		return c;
	}

}
