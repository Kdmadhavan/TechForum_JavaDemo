package com.TechForum.controlstatements;

public class Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int i=5;
      while(i>=1) {
    	  System.out.print(i+" ");
    	  i--;
      }
	}

}
