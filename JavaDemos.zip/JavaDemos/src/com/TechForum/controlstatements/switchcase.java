package com.TechForum.controlstatements;

public class switchcase {
//single variable & constance value vs independent logical expressions
	
	char ch='d';
	
	switch(city) {
	case 'm'
	}
	
}
