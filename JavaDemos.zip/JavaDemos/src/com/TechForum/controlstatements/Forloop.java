package com.TechForum.controlstatements;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       for(int i=1;i<=10;i=i+2) { 
    	   
    	   System.out.println(i);
       }
	}

}
/*
 * find sum of n values
 *
 * find prime numbers bw 1 to 20
 * 
 */
