package com.TechForum.controlstatements;

import java.util.Scanner;

public class Ifstatements {
    //how to get input from user----using scanner class
	public static void main(String[] args) {
		
       	Scanner s=new Scanner(System.in);
        System.out.println("please enter an int values");
        System.out.println("Enter the value of a");
        int a=s.nextInt();
   
        if(a>=90) {
        	System.out.println("Grade A");
        }
        else if(a>=80){
        	System.out.println("Grade B");
        }
        else if(a>=70){
        	System.out.println("Grade c");
        }
        else if(a>=60) {
        	System.out.println("Grade D");
        }
        else {
        	System.out.println("Fail");
        }
}
}