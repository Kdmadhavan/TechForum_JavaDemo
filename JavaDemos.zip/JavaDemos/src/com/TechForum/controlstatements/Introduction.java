package com.TechForum.controlstatements;

public class Introduction {
         /*
          * sequential
          * selection
          * 
          * (condition){
          * 
          * }
          * 
          * {
          * 
          * 
          * }
          * loop
          * c=1;
          * (c<=5){
          * sop("Tony stark")
          * c++;
          * }
          */
	
	static void method1() {
		System.out.println("im from introduction class");
	}
	
	public static void main(String[] args) {
		method1();
	}
}
