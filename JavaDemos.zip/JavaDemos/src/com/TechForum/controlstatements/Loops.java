package com.TechForum.controlstatements;

public class Loops {
       /*
        * top-down(while and for) and bottom up(do while)
        */
	public static void main(String[] args) {
		

	int counter=1;
	while(counter<=5) {
		System.out.println("counter value is "+counter+" so im printing this");
		counter++;
	}
	System.out.println("counter value became "+counter+" so im coming out of the loop");
}
}