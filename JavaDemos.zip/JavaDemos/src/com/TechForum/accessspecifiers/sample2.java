package com.TechForum.accessspecifiers;

public class sample2 extends Sample {
public static void main(String[] args) {
	System.out.println(a);
}
}
