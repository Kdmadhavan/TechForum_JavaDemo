package com.TechForum.accessspecifiers;

public class Sample {
	static int a =2;
//Access specifiers for variables,methods and contructors
//public--same class,class in same package,subclass in same package,subclass in outside package,non-subclass outside the same package
//protected--same class,class in same package,subclass in same package,subclass in outside package
//default-same class,class in same package,subclass in same package
//private-same class
	 
}
