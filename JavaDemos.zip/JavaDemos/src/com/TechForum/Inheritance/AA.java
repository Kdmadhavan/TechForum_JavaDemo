package com.TechForum.Inheritance;

public class AA {
static int x=50;
}
