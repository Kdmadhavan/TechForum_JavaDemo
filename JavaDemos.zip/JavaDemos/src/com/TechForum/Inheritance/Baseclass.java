package com.TechForum.Inheritance;

public class Baseclass {
	 void features()
	  {      
	    System.out.println("Feature A");      
	    System.out.println("Feature B");   
	  } 
}
