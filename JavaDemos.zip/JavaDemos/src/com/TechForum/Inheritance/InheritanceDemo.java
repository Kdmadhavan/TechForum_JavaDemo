package com.TechForum.Inheritance;

public class InheritanceDemo {
public static void main(String[] args) {
	NRIAccount n=new NRIAccount();
	n.depositMoney();
	n.withdrawMoney();
	n.applyfixeddeposit();
	SeniorCitizenAccount s=new SeniorCitizenAccount();
	s.depositMoney();
	s.withdrawMoney();
	s.applyfixeddeposit();
}
}
