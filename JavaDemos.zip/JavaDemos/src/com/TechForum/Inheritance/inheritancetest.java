package com.TechForum.Inheritance;

public class inheritancetest {

}
