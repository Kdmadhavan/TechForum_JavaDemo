package com.TechForum.Inheritance;

public class Derivedclass extends Baseclass {
	 void ownFeature()
	  {         
	     System.out.println("Feature C");   
	  } 
}
