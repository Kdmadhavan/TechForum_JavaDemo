package com.TechForum.Inheritance;

public class NRIAccount extends BankAccount{
    
	public void applyfixeddeposit() {
	    interestRate=6.5;
		System.out.println(interestRate);
	}
}
