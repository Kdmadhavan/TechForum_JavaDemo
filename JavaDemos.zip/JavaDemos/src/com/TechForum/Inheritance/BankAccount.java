package com.TechForum.Inheritance;

public class BankAccount {
     double withdrawAmount=150;
     double depositAmount=250;
     double balance;
     double interestRate=9.5;
     
     public void depositMoney() {
    	 System.out.println("My deposited amount is "+depositAmount);
     }
     public void withdrawMoney() {
    	 System.out.println("My withdrawl amount is "+withdrawAmount);
    	 balance=depositAmount-withdrawAmount;
    	 System.out.println("My Balance amount is "+balance);

     }
}
