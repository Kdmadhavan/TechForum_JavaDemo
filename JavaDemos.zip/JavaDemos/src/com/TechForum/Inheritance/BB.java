package com.TechForum.Inheritance;

public class BB extends AA{
	static int x=60;
public static void main(String[] args) {
	System.out.println(x);
}
}
