package com.TechForum.Inheritance;

public class Subclass extends Superclass{
/*
 * same variable num is declared in the sub class
 * which is already present in superclass
 */
	
	void printnumber(int a) {
		System.out.println(a);
	}
	
	void printnumber() {
		super.printnumber();
		int num=110;
		System.out.println(num);
	}
	public static void main(String[] args) {
		Subclass s=new Subclass();
		s.printnumber();
	}
}
