package com.TechForum.Inheritance;

public class SeniorCitizenAccount extends BankAccount{
	public void applyfixeddeposit() {
	    interestRate=10.5;
		System.out.println(interestRate);
	}
}
