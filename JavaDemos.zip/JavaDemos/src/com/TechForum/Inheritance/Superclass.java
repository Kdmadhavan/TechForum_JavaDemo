package com.TechForum.Inheritance;

public class Superclass {

	
	
	void printnumber() {
		int num=100;
		System.out.println(num);
	}
}
