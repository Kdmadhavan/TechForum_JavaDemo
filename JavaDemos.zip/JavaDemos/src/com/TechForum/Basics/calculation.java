package com.TechForum.Basics;

public class calculation {
     /*
      * declare 5 variables as marks like english,tamil,like that
      * declare another variable as name;
      * create a method which can sum all the marks and print it in console
      * create another method which can make an average and print it in console
      * create main method
      * create 3 objects as student1...3;
      * initialise the marks variable and name for seperate objects
      *  
      */
}
