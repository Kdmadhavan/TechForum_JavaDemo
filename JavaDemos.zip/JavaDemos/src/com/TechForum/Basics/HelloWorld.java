package com.TechForum.Basics;

public class HelloWorld {
	
public static void main(String[] args) {
	int a=25;
	System.out.println("The value of a");
	
}

}
