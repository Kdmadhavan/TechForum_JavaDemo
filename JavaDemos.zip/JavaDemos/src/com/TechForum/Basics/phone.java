package com.TechForum.Basics;


public class phone {
     //properties and actions
	
	double screensize;
	String OS;
	int price;
	
	public void call() {
		System.out.println("im calling to others");
	}
	public void msg() {
		System.out.println("i used to send msgs as txt" );
	}
	public static void main(String[] args) {
		phone samsung=new phone();
		phone iphone=new phone();
		samsung.OS="Android";
		iphone.OS="IOS";
		System.out.println("The os used for samsung is "+samsung.OS);
		samsung.call();
	}
	
}
