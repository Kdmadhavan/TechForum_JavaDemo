package com.TechForum.Basics;

public class Structureofclass {
      /*
       * class Definition
       * {
       *     variable declarations with its datatypes
       *     method declarations and its statements(Blocks)
       *     constructor declarations and its statements
       *     object definitions 
       * }
       */
	 // datatypes and variables
	   //syntax of variabe declaration
	  //[datatype][variable name]=[value];
	  //[datatype][variable name]; 
	
	//datatypes and its types
	int x=25;
	double y=25.654;
	String name="kiruba";
	
	/*
	 * Primitive data types(built in types)
	 * Non primitive data types(derived types)
	 */
	
	//Numeric------- byte,int,short,long,double,float
	//Non-numeric--- character,boolean
	
	public static void main(String[] args) {
		byte num=127;//-126 to 127
		System.out.println(num);
		short num2=24;//16 bit memory
		int num3=1234567890;//32 bit memory
		long num4=2234567890l;//
		float num5=23.5f;
		float result=num2+num3+num4+num+num5;
		
		float num6=25.4f;
		double num7=25.4;
		int d='r';
		System.out.println(d);
		
		//+,-,*,/,%
		
		//int,double,String,char,boolean
		
		
		
	}
	
	
	
	
	
	
	
	

}
