package com.TechForum.Basics;

public class operators {
   //  +-/*%
	/*
	 * > < >= <= == != ----Relational
	 * && || !-----Logical
	 * = ---Assignment
	 * ++ -- increment/decrement(unary)
	 */
	public static void main(String[] args) {
		int a=20;
		int b=35;
		int c=45;
		
		a+=1;//a=a+1
		b-=1;//b=b-1
	  //++c or c++
	//	++c is equivalent to c=c+1;
		System.out.println(c++ + ++c);

	}
}
