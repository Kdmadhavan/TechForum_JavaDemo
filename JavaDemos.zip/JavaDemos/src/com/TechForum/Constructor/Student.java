package com.TechForum.Constructor;

public class Student {
     String name;
     int rollno;
     String schoolname;
     String city;
     
     Student( String name,int rollno,String schoolname,String city){
    	 this.name=name;
    	 this.rollno=rollno;
    	 this.schoolname=schoolname;
    	 this.city=city;
     }
     void  display() {
    	 System.out.println(name+" "+rollno+" "+schoolname+" "+city);
     }
     public static void main(String[] args) {
		Student s=new Student("kiruba",25,"VMHS","Chennai");
		s.display();
	}
}
