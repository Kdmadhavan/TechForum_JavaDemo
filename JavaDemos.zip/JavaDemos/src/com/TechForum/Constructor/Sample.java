package com.TechForum.Constructor;

public class Sample {

	
	Sample(int a,int b){
		System.out.println(a+b);
	}
	
	public static void main(String[] args) {
		Sample s=new Sample(20,30);
	}
}
