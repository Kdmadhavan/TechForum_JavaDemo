package com.TechForum.Constructor;

public class Demo {

	Webdriver driver;
	
	
	static Base driver() {
		
		Base b=new Base(driver);
		return b;
	}
	
	
	
	Demo(){//calling default or zero argument constructor
		System.out.println("zero argument constructor");
	}
	
	Demo(int a){//parameterized constructor
		System.out.println("Single argument");
	}
	Demo(float a){
		System.out.println("Single argument with double");
	}
	public static void main(String[] args) {
		Demo d=new Demo(20);
		driver();
	}
}
