package com.TechForum.Constructor;

public class Base {

	
	Base(Webdriver driver){
		driver=new chromedriver();
		
	}
}
