package com.TechForum.Constructor;

public class Person {

	static String name;
	static int age;
	static String address;
	Person(){
		name="leela";
		age=5;
		address="Chennai";
	}

	static void display() {
		System.out.println(name+" "+age+" "+address);
	}
	
	public static void main(String[] args) {
	     Person p=new Person();
	     display();
	}
}
