package com.TechForum.Methods;

public class Test {

	Student m1() {
        System.out.println("M1 method");
        Student st=new Student();
        return st;
	}
}
