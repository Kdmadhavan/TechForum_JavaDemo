package com.TechForum.Methods;

public class Addition {

public static void add(int aa,int bb) {
         System.out.println(aa+bb);//instance methods
	}
/*
 * primitive data type-int,float,double, or reference type or void
 */
public int square(int num) {
	int sq= num*num;
	return sq;
}

public static void main(String[] args) {
	add(20,30);
}
}

