package com.TechForum.Methods;

public class Student {

}
