package Encapsulation;

public class EncapsulatedTest {
 public static void main(String[] args) {
	Student s=new Student();
	
	s.setName("priya");
	System.out.println(s.getName());
}
}
