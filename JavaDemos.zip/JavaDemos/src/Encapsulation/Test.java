package Encapsulation;

public class Test extends Student{
      public static void main(String[] args) {
		System.out.println(x);
	}
}
