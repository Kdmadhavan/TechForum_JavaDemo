package OOPs;

/*
 * Object oriented programming
 * Encapsulation 
 * Polymorphism
 * Inheritance
 * Absraction
 */
